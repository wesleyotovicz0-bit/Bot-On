# SPDX-License-Identifier: MIT

from typing import Literal, NamedTuple

__version__ = "2.11.0a81+geba3b43f"


class VersionInfo(NamedTuple):
    major: int
    minor: int
    micro: int
    releaselevel: Literal["alpha", "beta", "candidate", "final"]
    serial: int

version_info: VersionInfo = VersionInfo(2, 11, 0, 'alpha', 81)

