# SPDX-License-Identifier: MIT

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import (
    TYPE_CHECKING,
    ClassVar,
    Generic,
    TypeAlias,
    TypeVar,
)

from ...components import AnySelectMenu, SelectDefaultValue
from ...object import Object
from ...utils import MISSING, humanize_list, iscoroutinefunction
from ..item import Item

__all__ = ("BaseSelect",)

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence

    from typing_extensions import ParamSpec, Self

    from ...abc import Snowflake
    from ...enums import ComponentType, SelectDefaultValueType
    from ...interactions import MessageInteraction
    from ..item import DecoratedItem, ItemCallbackType
    from ..view import View

else:
    ParamSpec = TypeVar


S_co = TypeVar("S_co", bound="BaseSelect", covariant=True)
V_co = TypeVar("V_co", bound="View | None", covariant=True)
SelectMenuT = TypeVar("SelectMenuT", bound=AnySelectMenu)
SelectValueT = TypeVar("SelectValueT")
P = ParamSpec("P")

SelectDefaultValueMultiInputType: TypeAlias = SelectValueT | SelectDefaultValue
# almost the same as above, but with `Object`; used for selects where the type isn't ambiguous (i.e. all except mentionable select)
SelectDefaultValueInputType: TypeAlias = SelectDefaultValueMultiInputType[SelectValueT] | Object


class BaseSelect(Generic[SelectMenuT, SelectValueT, V_co], Item[V_co], ABC):
    """Represents an abstract UI select menu.

    This is usually represented as a drop down menu.

    This isn't meant to be used directly, instead use one of the concrete select menu types:

    - :class:`disnake.ui.StringSelect`
    - :class:`disnake.ui.UserSelect`
    - :class:`disnake.ui.RoleSelect`
    - :class:`disnake.ui.MentionableSelect`
    - :class:`disnake.ui.ChannelSelect`

    .. versionadded:: 2.7
    """

    __repr_attributes__: ClassVar[tuple[str, ...]] = (
        "placeholder",
        "min_values",
        "max_values",
        "disabled",
        "required",
    )
    # We have to set this to MISSING in order to overwrite the abstract property from UIComponent
    _underlying: SelectMenuT = MISSING

    # Subclasses are expected to set this
    _default_value_type_map: ClassVar[Mapping[SelectDefaultValueType, tuple[type[Snowflake], ...]]]

    def __init__(
        self,
        underlying_type: type[SelectMenuT],
        component_type: ComponentType,
        *,
        custom_id: str,
        placeholder: str | None,
        min_values: int,
        max_values: int,
        disabled: bool,
        default_values: Sequence[SelectDefaultValueInputType[SelectValueT]] | None,
        required: bool,
        id: int,
        row: int | None,
    ) -> None:
        super().__init__()
        self._selected_values: list[SelectValueT] = []
        self._provided_custom_id = custom_id is not MISSING
        custom_id = os.urandom(16).hex() if custom_id is MISSING else custom_id
        self._underlying = underlying_type._raw_construct(
            type=component_type,
            id=id,
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            default_values=self._transform_default_values(default_values) if default_values else [],
            required=required,
        )
        self.row = row

    @property
    def custom_id(self) -> str:
        """:class:`str`: The ID of the select menu that gets received during an interaction."""
        return self._underlying.custom_id

    @custom_id.setter
    def custom_id(self, value: str) -> None:
        if not isinstance(value, str):
            msg = "custom_id must be None or str"
            raise TypeError(msg)

        self._underlying.custom_id = value

    @property
    def placeholder(self) -> str | None:
        """:class:`str` | :data:`None`: The placeholder text that is shown if nothing is selected, if any."""
        return self._underlying.placeholder

    @placeholder.setter
    def placeholder(self, value: str | None) -> None:
        if value is not None and not isinstance(value, str):
            msg = "placeholder must be None or str"
            raise TypeError(msg)

        self._underlying.placeholder = value

    @property
    def min_values(self) -> int:
        """:class:`int`: The minimum number of items that must be chosen for this select menu."""
        return self._underlying.min_values

    @min_values.setter
    def min_values(self, value: int) -> None:
        self._underlying.min_values = int(value)

    @property
    def max_values(self) -> int:
        """:class:`int`: The maximum number of items that must be chosen for this select menu."""
        return self._underlying.max_values

    @max_values.setter
    def max_values(self, value: int) -> None:
        self._underlying.max_values = int(value)

    @property
    def disabled(self) -> bool:
        """:class:`bool`: Whether the select menu is disabled."""
        return self._underlying.disabled

    @disabled.setter
    def disabled(self, value: bool) -> None:
        self._underlying.disabled = bool(value)

    @property
    def default_values(self) -> list[SelectDefaultValue]:
        r""":class:`list`\[:class:`.SelectDefaultValue`]: The list of values that are selected by default.
        Only available for auto-populated select menus.
        """
        return self._underlying.default_values

    @default_values.setter
    def default_values(
        self, value: Sequence[SelectDefaultValueInputType[SelectValueT]] | None
    ) -> None:
        self._underlying.default_values = self._transform_default_values(value) if value else []

    @property
    def required(self) -> bool:
        """:class:`bool`: Whether the select menu is required.
        Only applies to components in modals.

        .. versionadded:: 2.11
        """
        return self._underlying.required

    @required.setter
    def required(self, value: bool) -> None:
        self._underlying.required = bool(value)

    @property
    def values(self) -> list[SelectValueT]:
        return self._selected_values

    @property
    def width(self) -> int:
        return 5

    def refresh_component(self, component: SelectMenuT) -> None:
        self._underlying = component

    def refresh_state(self, interaction: MessageInteraction) -> None:
        self._selected_values = interaction.resolved_values  # pyright: ignore[reportAttributeAccessIssue]

    @classmethod
    @abstractmethod
    def from_component(cls, component: SelectMenuT) -> Self:
        raise NotImplementedError

    def is_dispatchable(self) -> bool:
        """Whether the select menu is dispatchable. This will always return ``True``.

        :return type: :class:`bool`
        """
        return True

    @classmethod
    def _transform_default_values(
        cls, values: Sequence[SelectDefaultValueInputType[SelectValueT]]
    ) -> list[SelectDefaultValue]:
        result: list[SelectDefaultValue] = []

        for value in values:
            # If we have a SelectDefaultValue, just use it as-is
            if isinstance(value, SelectDefaultValue):
                if value.type not in cls._default_value_type_map:
                    allowed_types = [str(t) for t in cls._default_value_type_map]
                    msg = f"SelectDefaultValue.type should be {humanize_list(allowed_types, 'or')}, not {value.type}"
                    raise ValueError(msg)
                result.append(value)
                continue

            # Otherwise, look through the list of allowed input types and
            # get the associated SelectDefaultValueType
            for (
                value_type,  # noqa: B007  # we use value_type outside of the loop
                types,
            ) in cls._default_value_type_map.items():
                if isinstance(value, types):
                    break
            else:
                allowed_types = [
                    t.__name__ for ts in cls._default_value_type_map.values() for t in ts
                ]
                allowed_types.append(SelectDefaultValue.__name__)
                msg = f"Expected type of default value to be {humanize_list(allowed_types, 'or')}, not {type(value)!r}"
                raise TypeError(msg)

            result.append(SelectDefaultValue(value.id, value_type))

        return result


def _create_decorator(
    # FIXME(3.0): rename `cls` parameter to more closely represent any callable argument type
    cls: Callable[P, S_co],
    /,
    *args: P.args,
    **kwargs: P.kwargs,
) -> Callable[[ItemCallbackType[V_co, S_co]], DecoratedItem[S_co]]:
    if args:
        # the `*args` def above is just to satisfy the typechecker
        msg = "expected no *args"
        raise RuntimeError(msg)

    if not callable(cls):
        msg = "cls argument must be callable"
        raise TypeError(msg)

    def decorator(func: ItemCallbackType[V_co, S_co]) -> DecoratedItem[S_co]:
        if not iscoroutinefunction(func):
            msg = "select function must be a coroutine function"
            raise TypeError(msg)

        func.__discord_ui_model_type__ = cls
        func.__discord_ui_model_kwargs__ = kwargs
        return func  # pyright: ignore[reportReturnType]

    return decorator
