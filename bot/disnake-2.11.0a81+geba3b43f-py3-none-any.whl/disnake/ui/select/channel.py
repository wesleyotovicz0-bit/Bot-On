# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    TypeVar,
    overload,
)

from ...abc import GuildChannel
from ...channel import DMChannel, GroupChannel, PartialMessageable
from ...components import ChannelSelectMenu
from ...enums import ChannelType, ComponentType, SelectDefaultValueType
from ...object import Object
from ...threads import Thread
from ...utils import MISSING
from .base import BaseSelect, V_co, _create_decorator

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence

    from typing_extensions import Self

    from ...abc import AnyChannel, Snowflake
    from ..item import DecoratedItem, ItemCallbackType
    from .base import P, SelectDefaultValueInputType


__all__ = (
    "ChannelSelect",
    "channel_select",
)


class ChannelSelect(BaseSelect[ChannelSelectMenu, "AnyChannel", V_co]):
    r"""Represents a UI channel select menu.

    This is usually represented as a drop down menu.

    In order to get the selected items that the user has chosen, use :attr:`.values`.

    .. versionadded:: 2.7

    Parameters
    ----------
    custom_id: :class:`str`
        The ID of the select menu that gets received during an interaction.
        If not given then one is generated for you.
    placeholder: :class:`str` | :data:`None`
        The placeholder text that is shown if nothing is selected, if any.
    min_values: :class:`int`
        The minimum number of items that must be chosen for this select menu.
        Defaults to 1 and must be between 1 and 25.
    max_values: :class:`int`
        The maximum number of items that must be chosen for this select menu.
        Defaults to 1 and must be between 1 and 25.
    disabled: :class:`bool`
        Whether the select is disabled.
    channel_types: :class:`list`\[:class:`.ChannelType`] | :data:`None`
        The list of channel types that can be selected in this select menu.
        Defaults to all types (i.e. :data:`None`).
    default_values: :class:`~collections.abc.Sequence`\[:class:`.abc.GuildChannel` | :class:`.Thread` | :class:`.abc.PrivateChannel` | :class:`.PartialMessageable` | :class:`.SelectDefaultValue` | :class:`.Object`] | :data:`None`
        The list of values (channels) that are selected by default.
        If set, the number of items must be within the bounds set by ``min_values`` and ``max_values``.

        .. versionadded:: 2.10
    required: :class:`bool`
        Whether the select menu is required. Only applies to components in modals.
        Defaults to ``True``.

        .. versionadded:: 2.11
    id: :class:`int`
        The numeric identifier for the component. Must be unique within a message or modal.
        This is always present in components received from the API.
        If set to ``0`` (the default) when sending a component, the API will assign
        sequential identifiers to the components in the message or modal.

        .. versionadded:: 2.11
    row: :class:`int` | :data:`None`
        The relative row this select menu belongs to. A Discord component can only have 5
        rows. By default, items are arranged automatically into those 5 rows. If you'd
        like to control the relative positioning of the row then passing an index is advised.
        For example, row=1 will show up before row=2. Defaults to :data:`None`, which is automatic
        ordering. The row number must be between 0 and 4 (i.e. zero indexed).

    Attributes
    ----------
    values: :class:`list`\[:class:`.abc.GuildChannel` | :class:`.Thread` | :class:`.abc.PrivateChannel` | :class:`.PartialMessageable`]
        A list of channels that have been selected by the user.
    """

    __repr_attributes__: ClassVar[tuple[str, ...]] = (
        *BaseSelect.__repr_attributes__,
        "channel_types",
    )

    _default_value_type_map: ClassVar[
        Mapping[SelectDefaultValueType, tuple[type[Snowflake], ...]]
    ] = {
        SelectDefaultValueType.channel: (
            GuildChannel,
            Thread,
            DMChannel,
            GroupChannel,
            PartialMessageable,
            Object,
        ),
    }

    @overload
    def __init__(
        self: ChannelSelect[None],
        *,
        custom_id: str = ...,
        placeholder: str | None = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        channel_types: list[ChannelType] | None = None,
        default_values: Sequence[SelectDefaultValueInputType[AnyChannel]] | None = None,
        required: bool = True,
        id: int = 0,
        row: int | None = None,
    ) -> None: ...

    @overload
    def __init__(
        self: ChannelSelect[V_co],
        *,
        custom_id: str = ...,
        placeholder: str | None = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        channel_types: list[ChannelType] | None = None,
        default_values: Sequence[SelectDefaultValueInputType[AnyChannel]] | None = None,
        required: bool = True,
        id: int = 0,
        row: int | None = None,
    ) -> None: ...

    def __init__(
        self,
        *,
        custom_id: str = MISSING,
        placeholder: str | None = None,
        min_values: int = 1,
        max_values: int = 1,
        disabled: bool = False,
        channel_types: list[ChannelType] | None = None,
        default_values: Sequence[SelectDefaultValueInputType[AnyChannel]] | None = None,
        required: bool = True,
        id: int = 0,
        row: int | None = None,
    ) -> None:
        super().__init__(
            ChannelSelectMenu,
            ComponentType.channel_select,
            custom_id=custom_id,
            placeholder=placeholder,
            min_values=min_values,
            max_values=max_values,
            disabled=disabled,
            default_values=default_values,
            required=required,
            id=id,
            row=row,
        )
        self._underlying.channel_types = channel_types or None

    @classmethod
    def from_component(cls, component: ChannelSelectMenu) -> Self:
        return cls(
            custom_id=component.custom_id,
            placeholder=component.placeholder,
            min_values=component.min_values,
            max_values=component.max_values,
            disabled=component.disabled,
            channel_types=component.channel_types,
            default_values=component.default_values,
            required=component.required,
            id=component.id,
            row=None,
        )

    @property
    def channel_types(self) -> list[ChannelType] | None:
        r""":class:`list`\[:class:`disnake.ChannelType`] | :data:`None`: A list of channel types that can be selected in this select menu."""
        return self._underlying.channel_types

    @channel_types.setter
    def channel_types(self, value: list[ChannelType] | None) -> None:
        if value is not None:
            if not isinstance(value, list):
                msg = "channel_types must be a list of ChannelType"
                raise TypeError(msg)
            if not all(isinstance(obj, ChannelType) for obj in value):
                msg = "all list items must be ChannelType"
                raise TypeError(msg)

        self._underlying.channel_types = value


S_co = TypeVar("S_co", bound="ChannelSelect", covariant=True)


@overload
def channel_select(
    *,
    placeholder: str | None = None,
    custom_id: str = ...,
    min_values: int = 1,
    max_values: int = 1,
    disabled: bool = False,
    channel_types: list[ChannelType] | None = None,
    default_values: Sequence[SelectDefaultValueInputType[AnyChannel]] | None = None,
    id: int = 0,
    row: int | None = None,
) -> Callable[
    [ItemCallbackType[V_co, ChannelSelect[V_co]]], DecoratedItem[ChannelSelect[V_co]]
]: ...


@overload
def channel_select(
    cls: Callable[P, S_co], *_: P.args, **kwargs: P.kwargs
) -> Callable[[ItemCallbackType[V_co, S_co]], DecoratedItem[S_co]]: ...


def channel_select(
    cls: Callable[..., S_co] = ChannelSelect[Any], **kwargs: Any
) -> Callable[[ItemCallbackType[V_co, S_co]], DecoratedItem[S_co]]:
    r"""A decorator that attaches a channel select menu to a component.

    The function being decorated should have three parameters: ``self`` representing
    the :class:`disnake.ui.View`, the :class:`disnake.ui.ChannelSelect` that was
    interacted with, and the :class:`disnake.MessageInteraction`.

    In order to get the selected items that the user has chosen within the callback
    use :attr:`ChannelSelect.values`.

    .. versionadded:: 2.7

    Parameters
    ----------
    cls: :class:`~collections.abc.Callable`\[..., :class:`ChannelSelect`]
        A callable (such as a :class:`ChannelSelect` subclass) returning an instance of a :class:`ChannelSelect`.
        If provided, the other parameters described below do not apply.
        Instead, this decorator will accept the same keyword arguments as the passed callable does.
    placeholder: :class:`str` | :data:`None`
        The placeholder text that is shown if nothing is selected, if any.
    custom_id: :class:`str`
        The ID of the select menu that gets received during an interaction.
        It is recommended not to set this parameter to prevent conflicts.
    min_values: :class:`int`
        The minimum number of items that must be chosen for this select menu.
        Defaults to 1 and must be between 1 and 25.
    max_values: :class:`int`
        The maximum number of items that must be chosen for this select menu.
        Defaults to 1 and must be between 1 and 25.
    disabled: :class:`bool`
        Whether the select is disabled. Defaults to ``False``.
    channel_types: :class:`list`\[:class:`.ChannelType`] | :data:`None`
        The list of channel types that can be selected in this select menu.
        Defaults to all types (i.e. :data:`None`).
    default_values: :class:`~collections.abc.Sequence`\[:class:`.abc.GuildChannel` | :class:`.Thread` | :class:`.abc.PrivateChannel` | :class:`.PartialMessageable` | :class:`.SelectDefaultValue` | :class:`.Object`] | :data:`None`
        The list of values (channels) that are selected by default.
        If set, the number of items must be within the bounds set by ``min_values`` and ``max_values``.

        .. versionadded:: 2.10
    id: :class:`int`
        The numeric identifier for the component. Must be unique within a view.
        If set to ``0`` (the default) when sending a component, the API will assign
        sequential identifiers to the components in the view.

        .. versionadded:: 2.11
    row: :class:`int` | :data:`None`
        The relative row this select menu belongs to. A Discord component can only have 5
        rows. By default, items are arranged automatically into those 5 rows. If you'd
        like to control the relative positioning of the row then passing an index is advised.
        For example, row=1 will show up before row=2. Defaults to :data:`None`, which is automatic
        ordering. The row number must be between 0 and 4 (i.e. zero indexed).

    Raises
    ------
    TypeError
        The decorated function was not a coroutine function,
        or the ``cls`` parameter was not a callable or a subclass of :class:`ChannelSelect`.
    """
    return _create_decorator(cls, **kwargs)
