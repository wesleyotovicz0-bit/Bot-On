# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from ..components import Thumbnail as ThumbnailComponent, handle_media_item_input
from ..enums import ComponentType
from ..utils import MISSING
from .item import UIComponent

if TYPE_CHECKING:
    from typing_extensions import Self

    from ..components import MediaItemInput, UnfurledMediaItem

__all__ = ("Thumbnail",)


class Thumbnail(UIComponent):
    """Represents a UI thumbnail.

    This is only supported as the :attr:`~.ui.Section.accessory` of a section component.

    .. versionadded:: 2.11

    Parameters
    ----------
    media: :class:`str` | :class:`.Asset` | :class:`.Attachment` | :class:`.UnfurledMediaItem`
        The media item to display. Can be an arbitrary URL or attachment
        reference (``attachment://<filename>``).
    description: :class:`str` | :data:`None`
        The thumbnail's description ("alt text"), if any.
    spoiler: :class:`bool`
        Whether the thumbnail is marked as a spoiler. Defaults to ``False``.
    id: :class:`int`
        The numeric identifier for the component. Must be unique within a message.
        This is always present in components received from the API.
        If set to ``0`` (the default) when sending a component, the API will assign
        sequential identifiers to the components in the message.
    """

    __repr_attributes__: ClassVar[tuple[str, ...]] = (
        "media",
        "description",
        "spoiler",
    )
    # We have to set this to MISSING in order to overwrite the abstract property from UIComponent
    _underlying: ThumbnailComponent = MISSING

    def __init__(
        self,
        media: MediaItemInput,
        description: str | None = None,
        *,
        spoiler: bool = False,
        id: int = 0,
    ) -> None:
        self._underlying = ThumbnailComponent._raw_construct(
            type=ComponentType.thumbnail,
            id=id,
            media=handle_media_item_input(media),
            description=description,
            spoiler=spoiler,
        )

    @property
    def media(self) -> UnfurledMediaItem:
        """:class:`.UnfurledMediaItem`: The media item to display."""
        return self._underlying.media

    @media.setter
    def media(self, value: MediaItemInput) -> None:
        self._underlying.media = handle_media_item_input(value)

    @property
    def description(self) -> str | None:
        """:class:`str` | :data:`None`: The thumbnail's description ("alt text"), if any."""
        return self._underlying.description

    @description.setter
    def description(self, value: str | None) -> None:
        self._underlying.description = value

    @property
    def spoiler(self) -> bool:
        """:class:`bool`: Whether the thumbnail is marked as a spoiler."""
        return self._underlying.spoiler

    @spoiler.setter
    def spoiler(self, value: bool) -> None:
        self._underlying.spoiler = value

    @classmethod
    def from_component(cls, thumbnail: ThumbnailComponent) -> Self:
        return cls(
            media=thumbnail.media,
            description=thumbnail.description,
            spoiler=thumbnail.spoiler,
            id=thumbnail.id,
        )
